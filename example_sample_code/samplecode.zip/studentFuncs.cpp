#include "studentFuncs.h"

int studentAdd(int a, int b) {
    return a + b;
}

int studentSubtract(int a, int b) {
    return a - b;
}

int studentMultiply(int a, int b) {
    return a * b;
}

int studentDivide(int a, int b) {
    return a / b;
}