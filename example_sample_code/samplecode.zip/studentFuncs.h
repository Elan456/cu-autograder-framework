

int studentAdd(int v1, int v2);
int studentSubtract(int v1, int v2);
int studentMultiply(int v1, int v2);
int studentDivide(int v1, int v2);
int studentInfiniteDivide(int v1, int v2);